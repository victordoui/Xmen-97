<img src ="https://files.tecnoblog.net/wp-content/uploads/2019/05/league-of-legends.jpg">

# League of Legends Champions Selector <a href="https://emoji.gg/emoji/8396-square-lol"><img src="https://cdn3.emoji.gg/emojis/8396-square-lol.png" width="40px" height="40px" alt="Square_Lol"></a>

This project is a simple champion selector web application inspired by the @devemdobro channel's project. It allows users to choose from 8 popular League of Legends champions: Yasuo, Katarina, Jinx, Zed, Ahri, Akali, Teemo, and Caitlyn.

# Technologies Used ✅
<a href="https://skillicons.dev">
    <img src="https://skillicons.dev/icons?i=html" />
    <img src="https://skillicons.dev/icons?i=css" />
    <img src="https://skillicons.dev/icons?i=js" />
</a>

# How to Use 🚀 
1. Open the [Simple Champion Selector](https://lol-select-champion.vercel.app/) website in your browser.
2. Click on the availables champions icons to select your champion.

# Credits 💡
Project inspired by @devemdobro.
Champion icons and images from League of Legends website.

# License
This project is licensed under the MIT License. Feel free to use, modify, and distribute it as you like. Happy gaming! 🎮
